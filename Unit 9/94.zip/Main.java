class Main {
  public static void main(String[] args) {
    Fish f = new Fish(3); //Call a superclass constructor with super.
    f.noise("yeehaw"); //Call a superclass method with super.
    
  }
}

